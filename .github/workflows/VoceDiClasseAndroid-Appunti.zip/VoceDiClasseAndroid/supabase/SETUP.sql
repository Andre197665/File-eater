-- Schema backend Voce di Classe. Già applicato al progetto Supabase configurato.
-- I codici sono memorizzati solo come hash; non inserire mai una service_role key nell'app.
create table if not exists public.class_members (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role text not null default 'studente' check (role in ('admin','rep','studente')),
  created_at timestamptz not null default now()
);
create table if not exists public.class_invites (
  id boolean primary key default true check (id), invite_hash text not null,
  admin_pin_hash text not null, active boolean not null default true
);
insert into public.class_invites(id, invite_hash, admin_pin_hash, active)
values (true, '2ab1dcdef2b934994d1947db061d9ffb1c4b28ec908dd14da1c7ea5420913784', '0b4ecb7a315572a452a72d73d9d9d5873cf167b75797f55469744e149db2d12a', true)
on conflict (id) do update set invite_hash=excluded.invite_hash, admin_pin_hash=excluded.admin_pin_hash, active=true;
create table if not exists public.class_state (
  id text primary key check (id = 'main'),
  state jsonb not null default '{"users":{},"n":1,"ass":null,"news":[],"polls":[],"props":[],"ev":[],"tasks":[]}'::jsonb,
  updated_at timestamptz not null default now(), updated_by uuid references auth.users(id)
);
insert into public.class_state(id) values ('main') on conflict (id) do nothing;
create table if not exists public.class_box (
  id bigint generated always as identity primary key, category text not null, message text not null,
  created_at timestamptz not null default now(), created_by uuid not null default auth.uid() references auth.users(id) on delete cascade
);
create index if not exists class_box_created_by_idx on public.class_box(created_by);
create index if not exists class_state_updated_by_idx on public.class_state(updated_by);

alter table public.class_members enable row level security;
alter table public.class_invites enable row level security;
alter table public.class_state enable row level security;
alter table public.class_box enable row level security;
revoke all on public.class_members, public.class_invites from anon, authenticated;
revoke all on public.class_state, public.class_box from anon;
grant select, insert, update on public.class_state to authenticated;
grant insert, select, delete on public.class_box to authenticated;
grant usage, select on sequence public.class_box_id_seq to authenticated;

create or replace function public.is_class_member() returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.class_members m where m.user_id = (select auth.uid()));
$$;
create or replace function public.is_class_rep() returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.class_members m where m.user_id = (select auth.uid()) and m.role in ('admin','rep'));
$$;
create or replace function public.join_class(p_code text, p_display_name text, p_admin_pin text default '') returns text
language plpgsql security definer set search_path = '' as $$
declare v_role text := 'studente'; v_valid boolean; v_name text := trim(coalesce(p_display_name, '')); v_is_admin_name boolean;
begin
  if auth.uid() is null then raise exception 'Devi autenticarti prima di entrare'; end if;
  if length(v_name) < 2 or length(v_name) > 80 then raise exception 'Inserisci un nome valido'; end if;
  select i.active and i.invite_hash = encode(extensions.digest(convert_to(lower(trim(coalesce(p_code,''))), 'UTF8'), 'sha256'), 'hex') into v_valid from public.class_invites i where i.id = true;
  if coalesce(v_valid, false) is not true then raise exception 'Codice classe non valido'; end if;
  v_is_admin_name := lower(v_name) in ('josè','josé','orlando','gianluca','bortoadmin');
  if v_is_admin_name then
    if not exists (select 1 from public.class_invites i where i.id = true and i.admin_pin_hash = encode(extensions.digest(convert_to(coalesce(p_admin_pin,''), 'UTF8'), 'sha256'), 'hex')) then raise exception 'PIN admin non valido'; end if;
    v_role := 'admin';
  end if;
  insert into public.class_members(user_id, display_name, role) values ((select auth.uid()), v_name, v_role)
  on conflict (user_id) do update set display_name = excluded.display_name, role = case when excluded.role = 'admin' then 'admin' else public.class_members.role end;
  return (select m.role from public.class_members m where m.user_id = (select auth.uid()));
end; $$;
create or replace function public.set_member_role(p_display_name text, p_role text) returns boolean
language plpgsql security definer set search_path = '' as $$
begin
  if not exists (select 1 from public.class_members m where m.user_id = (select auth.uid()) and m.role = 'admin') then raise exception 'Solo un admin può cambiare i ruoli'; end if;
  if p_role not in ('rep','studente') then raise exception 'Ruolo non valido'; end if;
  update public.class_members set role = p_role where lower(display_name) = lower(trim(p_display_name)) and role <> 'admin';
  return found;
end; $$;
create or replace function public.get_class_members() returns table(display_name text, member_role text)
language sql stable security definer set search_path = '' as $$
  select m.display_name, m.role from public.class_members m where public.is_class_rep() order by m.display_name;
$$;
create or replace function public.touch_class_state() returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = now(); new.updated_by = (select auth.uid()); return new; end; $$;
drop trigger if exists touch_class_state_updated_at on public.class_state;
create trigger touch_class_state_updated_at before update on public.class_state for each row execute function public.touch_class_state();

drop policy if exists class_state_member_select on public.class_state;
create policy class_state_member_select on public.class_state for select to authenticated using (public.is_class_member());
drop policy if exists class_state_member_insert on public.class_state;
create policy class_state_member_insert on public.class_state for insert to authenticated with check (public.is_class_member());
drop policy if exists class_state_member_update on public.class_state;
create policy class_state_member_update on public.class_state for update to authenticated using (public.is_class_member()) with check (public.is_class_member());
drop policy if exists class_box_member_insert on public.class_box;
create policy class_box_member_insert on public.class_box for insert to authenticated with check (public.is_class_member() and created_by = (select auth.uid()));
drop policy if exists class_box_rep_select on public.class_box;
create policy class_box_rep_select on public.class_box for select to authenticated using (public.is_class_rep());
drop policy if exists class_box_rep_delete on public.class_box;
create policy class_box_rep_delete on public.class_box for delete to authenticated using (public.is_class_rep());
revoke all on function public.is_class_member() from public, anon;
revoke all on function public.is_class_rep() from public, anon;
revoke all on function public.join_class(text,text,text) from public, anon;
revoke all on function public.set_member_role(text,text) from public, anon;
revoke all on function public.get_class_members() from public, anon;
grant execute on function public.is_class_member() to authenticated;
grant execute on function public.is_class_rep() to authenticated;
grant execute on function public.join_class(text,text,text) to authenticated;
grant execute on function public.set_member_role(text,text) to authenticated;
grant execute on function public.get_class_members() to authenticated;
