package it.vocediclasse.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    // IMPORTANT: replace with a long, random topic name shared only with your class.
    // ntfy public topics are not private; anyone who knows the topic can read messages.
    private static final String NTFY_TOPIC = "CAMBIA_TOPIC_CON_UN_NOME_LUNGO_CASUALE";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NtfyBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class NtfyBridge {
        @JavascriptInterface
        public void notifyClass(String title, String message) {
            // Only generic event notices are sent; no names, poll answers, or message contents.
            if (NTFY_TOPIC.startsWith("CAMBIA_")) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "Configura il topic ntfy in MainActivity.java", Toast.LENGTH_LONG).show());
                return;
            }
            executor.execute(() -> {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL("https://ntfy.sh/" + NTFY_TOPIC);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
                    conn.setRequestProperty("Title", title);
                    conn.setRequestProperty("Priority", "3");
                    byte[] body = message.getBytes(StandardCharsets.UTF_8);
                    try (OutputStream out = conn.getOutputStream()) { out.write(body); }
                    conn.getResponseCode();
                } catch (Exception ignored) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Notifica ntfy non inviata: controlla la connessione", Toast.LENGTH_SHORT).show());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else if (webView != null && webView.evaluateJavascript("window.goBack && window.goBack()", null) == null) super.onBackPressed();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
