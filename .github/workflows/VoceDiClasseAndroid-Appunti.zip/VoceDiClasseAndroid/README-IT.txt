VOCE DI CLASSE — progetto Android Studio con sincronizzazione Supabase + notifiche ntfy

COSA INCLUDE
- App HTML originale dentro una WebView Android.
- Sincronizzazione dei dati della classe tramite Supabase (bacheca, appunti condivisi con materia e argomento, sondaggi, proposte, date, compiti e ruoli), con aggiornamento periodico.
- Sezione Appunti: ogni membro può pubblicare materia, titolo, argomento e testo; chi pubblica può eliminare i propri appunti, gli admin possono eliminare tutti.
- Cassetta anonima separata dal resto dei dati: l'inserimento è consentito ai membri della classe e la lettura è controllata lato database per admin/rappresentanti.
- Notifiche ntfy generiche; i contenuti dei messaggi non vengono inviati alle notifiche.
- Schema SQL del backend in supabase/SETUP.sql.

PRIMA DEL PRIMO ACCESSO
1. Apri https://supabase.com/dashboard/project/rnxvfxkehgcpzkqccief/auth/providers
2. In Authentication / Sign In Providers abilita Anonymous Sign-Ins (accesso anonimo). È necessario perché l'app non raccoglie email o password.
3. Non condividere il PIN admin. Condividi il codice classe soltanto con i compagni che devono entrare.

ACCESSO ALLA CLASSE
- Codice classe: viene fornito separatamente dal proprietario del progetto.
- I quattro nomi admin previsti dall'app sono Josè, Orlando, Gianluca e BortoAdmin. Per ottenere il ruolo admin bisogna inserire il PIN admin corretto; la verifica viene eseguita dal database, non soltanto nell'interfaccia.
- I telefoni usano una sessione anonima salvata sul dispositivo. Se si cancellano i dati dell'app o si cambia telefono, bisogna rientrare con il codice classe; l'identità anonima precedente non si può recuperare automaticamente.

COMPILARE L'APK
1. Estrai lo ZIP.
2. Apri la cartella VoceDiClasseAndroid in Android Studio.
3. Accetta la sincronizzazione Gradle e installa gli eventuali componenti Android SDK richiesti.
4. Per provare sul telefono: Run > Run 'app'.
5. Per creare l'APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

REQUISITI
- Android 6.0 (API 23) o successivo.
- Connessione Internet per accedere ai dati condivisi e inviare notifiche.
- È un'app Android: un APK non si installa su iPhone.

NOTE IMPORTANTI
- Il progetto sorgente non è un APK compilato.
- Il codice publishable Supabase incluso nell'app è una chiave pubblica; la protezione dei dati dipende dalle policy RLS del database. Non inserire mai una service_role key nell'app.
- La sincronizzazione richiede la connessione. Evita di usare l'app offline per modificare dati condivisi: le modifiche locali non sono pensate come una coda offline completa.
- ntfy invia solo notifiche generiche. Un topic ntfy pubblico non è privato: non inserire informazioni personali nel titolo o nel testo delle notifiche.
- La cassetta anonima è salvata separatamente e le policy database consentono di leggerla solo ai membri con ruolo admin/rappresentante.
